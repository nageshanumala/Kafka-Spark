#!/bin/bash


# Last amended: 29/10/2018
# Myfolder: /home/ashok
# VM:  lubuntu_spark

## Objective:
# 		Generates Single  file having invoice
# 		Used to generate fake data
# 		for use in spark streaming
# 		Press ctrl+c to terminate for-loop

## Usage:
#   Open one terminal and run this file as:
#     	cd /home/ashok/Documents/fake
#    		bash invoice_file_gen.sh

#	 Data format: Order of Fields at the output
# 	  custmid, itemid, qty, datetime



# 1.0 First delete any existing files in the folder
echo "Deleting existing files from folder: spark/data "
echo "   "
cd /home/ashok/Documents/spark/data
rm -f *.csv
cd ~


# 2.0 Generate files at 10 seconds interval
echo "Creating  file invoice.csv "
python  /home/ashok/Documents/fake/fake_invoice_gen.py  >>  /home/ashok/Documents/spark/data/invoice.csv

################# END ###########################